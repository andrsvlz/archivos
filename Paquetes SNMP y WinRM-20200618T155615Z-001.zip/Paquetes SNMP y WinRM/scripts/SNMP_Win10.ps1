﻿$ErrorActionPreference="SilentlyContinue"
Stop-Transcript | out-null
$ErrorActionPreference = "Continue"
Start-Transcript -path C:\control\output.txt -append


$syscontact='Mesa de Servicios'


if (!(test-path "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\RFC1156Agent")){

if ([bool]((Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\RFC1156Agent").sysContact -ne $syscontact)){


Add-Type -AssemblyName System.IO.Compression.FileSystem
function Unzip
{
    param([string]$zipfile, [string]$outpath)

    [System.IO.Compression.ZipFile]::ExtractToDirectory($zipfile, $outpath)
}

$ErrorActionPreference = 'SilentlyContinue'
#check for windows release author Andres Velez #
$winrelease = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseID

if($winrelease -eq 1809) {
    #This windows release is 1809.
       mkdir c:\temp\
       [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};(New-Object Net.WebClient).downloadfile('https://192.168.47.27/comfenalco/1809.zip', 'c:\temp\1809.zip')
       Unzip "c:\temp\1809.zip" "C:\temp\"
        # Copy-Item -Path '\\solla.com\NETLOGON\Solla\SNMP_Install\Build1809' -Destination 'c:\tempsnmp\' -Recurse  

    $capability = Get-WindowsCapability -Online -Name "SNMP.Client*" -source  "C:\temp\snmp1809"
    #check to see if the SNMP client is installed
    if ($capability.State -eq "NotPresent"){
        #snmp.client not found, install it.

        $currentWU = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" | select -ExpandProperty UseWUServer
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -Value 0
        Restart-Service wuauserv
       
        Add-WindowsCapability -online -Name "$($capability.Name)" -source "C:\temp\snmp1809" -LimitAccess

        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -Value $currentWU
        Restart-Service wuauserv
    } else {
        #snmp client already installed.  Write a message to log or something else?
    } #=>if/else $capability.State

}




elseif($winrelease -gt 1809) {
    #This windows release is 1809.
     mkdir c:\temp\
     [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true};(New-Object Net.WebClient).downloadfile('https://192.168.47.27/comfenalco/1903.zip', 'c:\temp\1903.zip')
     unzip "c:\temp\1903.zip" "C:\temp\"
     #Copy-Item -Path '\\solla.com\NETLOGON\Solla\SNMP_Install\Build1903' -Destination 'c:\tempsnmp\'  -Recurse

    $capability = Get-WindowsCapability -Online -Name "SNMP.Client*" -source  "C:\temp\snmp1903"
    #check to see if the SNMP client is installed
    if ($capability.State -eq "NotPresent"){
        #snmp.client not found, install it.

        $currentWU = Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" | select -ExpandProperty UseWUServer
        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -Value 0
        Restart-Service wuauserv
       

        Add-WindowsCapability -online -Name "$($capability.Name)" -source "C:\temp\snmp1903" -LimitAccess



        Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -Value $currentWU
        Restart-Service wuauserv
    } else {
        #snmp client already installed.  Write a message to log or something else?
    } #=>if/else $capability.State

}
else
 {
    #This release of Windows 7.
    dism /online /enable-feature /featurename:SNMP
   
}
    $pmanagers = "192.168.47.27"
    $commstring = "MosaiCo2019"
    #Set SNMP Permitted Manager(s) ** WARNING : This will over write current settings **
    reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\RFC1156Agent" /v "sysContact" /t REG_SZ /d $syscontact /f | Out-Null
    reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\RFC1156Agent" /v "sysLocation" /t REG_SZ /d "444 21 89" /f | Out-Null
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\PermittedManagers" /v 1 /t REG_SZ /d localhost /f | Out-Null
#Used as counter for incremting permitted managers
$i = 2
Foreach ($manager in $pmanagers){
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\PermittedManagers" /v $i /t REG_SZ /d $manager /f | Out-Null
$i++
}
#Set SNMP Community String(s)- *Read Only*
Foreach ( $string in $commstring){
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\ValidCommunities" /v $string /t REG_DWORD /d 4 /f | Out-Null
        reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\SNMP\Parameters\TrapConfiguration\$string" /v 1 /t REG_SZ /d $pmanagers /f | Out-Null

        }

Remove-Item 'c:\temp\' -force -Recurse
##Verify Windows Servcies Are Enabled y crear comunidad+9
 Restart-Service "SNMP"
 Restart-Service "SNMP"
 #}
}
}

Stop-Transcript